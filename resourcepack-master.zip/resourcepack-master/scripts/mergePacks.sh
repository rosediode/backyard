#!/usr/bin/env bash
set -xe

arg_path_tmpdir="$1"
arg_path_pack="$2"
arg_path_meg4zip="$3"
arg_path_output="$4"

path_meg_pack="$arg_path_tmpdir/unzippedMeg"
unzip -d "$path_meg_pack" "$arg_path_meg4zip"

mkdir -p "$arg_path_output"

# copy our pack to output
rsync -vr "$arg_path_pack/" "$arg_path_output/"

# handle a known collision (spooky I know)
printf "Merging known collisions in '%s'\n" "assets/minecraft/atlases/blocks.json"
mkdir -p "$arg_path_output/assets/minecraft/atlases"
jq -s '.[0].sources += .[1].sources | .[0]' \
  "$arg_path_pack/assets/minecraft/atlases/blocks.json" \
  "$path_meg_pack/assets/minecraft/atlases/blocks.json" \
  >"$arg_path_output/assets/minecraft/atlases/blocks.json"
# remove the file from MEG that we merged in with our pack
rm "$path_meg_pack/assets/minecraft/atlases/blocks.json"

# exit if there's collisions we don't know about
if output_diff="$(diff -qr "$arg_path_pack/assets" "$path_meg_pack/assets" | grep -v "^Only in")"; then
  echo "error: more collisions need to be handled"
  echo "$output_diff"
  exit 1
fi

# copy the MEG files in now that they're collision-free
rsync -vr "$path_meg_pack/assets/" "$arg_path_output/assets/"

echo "merge successful"
