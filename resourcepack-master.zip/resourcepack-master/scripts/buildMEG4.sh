#!/usr/bin/env bash
set -xe

arg_path_tmpdir="$1"
arg_path_repo="$2"
arg_filepath_output="$3"
arg_image_name="${4:-"docker.yardpodcast.cc/minecraft/packer:latest"}"

printf "current user: '%s'\n" "$(id)"
printf "current directory: '%s'\n" "$(pwd)"

ls -lah ../
ls -lah

sleep 1

path_work="$arg_path_tmpdir/meg4"
mkdir -p "$path_work"
path_work="$(realpath "$path_work")"

path_src="$(realpath "$arg_path_repo/src")"

docker run --user root \
  -v "$path_src:/mnt/in" \
  -v "$path_work:/mnt/out" \
  "$arg_image_name"

du -sh "$path_work"
ls -lah "$path_work"

meg4_pack="$path_work/resource pack.zip"
test -f "$meg4_pack" || { printf "resource pack not found at: '%s'\n" "$meg4_pack"; exit 1; }

cp "$meg4_pack" "$arg_filepath_output"
