#!/usr/bin/env bash

arg_path_pack="$1"
arg_pack_output="$2"

arg_path_pack="$(realpath "$arg_path_pack")"

mkdir -p "$arg_pack_output"
arg_pack_output="$(realpath "$arg_pack_output")"

cat << EOF | sed 's/^  //' > "$arg_path_pack/default.toml"
  pack_directory = '/pack'
  output_file_path = '/mnt/out/pack.zip'
  #zip_spec_conformance_level = 'disregard'
  recompress_compressed_files = true
EOF

docker run \
  -v "$arg_path_pack/:/pack/" \
  -v "$arg_pack_output:/mnt/out" \
  ghcr.io/comunidadaylas/packsquash:0.4.0 \
  /pack/default.toml
