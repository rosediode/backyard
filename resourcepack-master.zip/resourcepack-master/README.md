## Quick Start
Place [Blockbench](https://www.blockbench.net) files in `src/models`. [ModelEngine](https://mythiccraft.io/index.php?resources/model-engine%E2%80%94ultimate-entity-model-manager-1-19-4-1-20-2.1213) generates a resource pack with these assets which we then merge into our own pack.

Our resource pack is in `src/pack`.

## External Resources

- [mcasset.cloud](https://mcasset.cloud) - place to get default minecraft assets without using local files
- [ModelEngine4 Wiki](https://git.lumine.io/mythiccraft/model-engine-4/-/wikis/home) - we use this plugin
- [PackSquash](https://github.com/ComunidadAylas/PackSquash) - we use this for zipping things up
